//
//  SideMenuViewController.swift
//  mySideMenu
//
//  Created by Akash on 6/20/18.
//  Copyright © 2018 Moin. All rights reserved.
//

import UIKit

enum Menu: Int {
    case DashBoard = 0
    case WhistleBlower
    case FAQ
    case ClientQuery
    case Contacts
    case Events
    case BankDetails
    case Request
    case Tasks
    case Tips
    case Followup
    case Holidays
    case Share
    case Settings
    case Logout
}

class SideMenuViewController: UITableViewController {
    
    var arrMenuIcon : [String] = [String]()
    var arrMenuTitle : [String] = [String]()
    
    @IBOutlet var headerView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = true
        
        arrMenuIcon = ["home","whistle_blower","faq","client_query","contacts","events","bank-details","request","tasks","side-menu-tips","followup","holidays","share","settings","logout"]
        
        arrMenuTitle = ["Dashboard","Whistle Blower","FAQ","Client Query","Contacts","Events","Bank Details","Request","Tasks","Tips","Follow Up","Holidays","Share","Settings","Logout"]
        
        tableView.tableHeaderView = headerView
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMenuTitle.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuTableViewCell", for: indexPath) as! SideMenuTableViewCell
        
        cell.imgIcon.image = UIImage(named: arrMenuIcon[indexPath.row])
        cell.lblTitle.text = arrMenuTitle[indexPath.row]
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let menu = Menu(rawValue: indexPath.item) {
            self.changeViewController(menu)
        }
    }
    
    //MARK: CHANGEVIEW CONTROLLER
    func changeViewController(_ menu : Menu) {
        switch menu {
        case.DashBoard: //DASHBOARD
            
            let dashboardVCObj = self.storyboard?.instantiateViewController(withIdentifier: "DashboardViewController") as! DashboardViewController
            self.navigationController?.pushViewController(dashboardVCObj, animated: true)
            
            break
        case .WhistleBlower: //WHISTLE BLOWER
            
            let whistleBlowerVCObj = self.storyboard?.instantiateViewController(withIdentifier: "WhistleBlowerViewController") as! WhistleBlowerViewController
            whistleBlowerVCObj.isFromMenu = true
            self.navigationController?.pushViewController(whistleBlowerVCObj, animated: true)
            
            break
        case .FAQ: //FAQ
            
            //            let faqVCObj = self.storyboard?.instantiateViewController(withIdentifier: "FAQViewController") as! FAQViewController
            //            self.navigationController?.pushViewController(faqVCObj, animated: true)
            
            break
        case .ClientQuery: //CLIENT QUERY
            
            //            let clientQueryVCObj = self.storyboard?.instantiateViewController(withIdentifier: "ClientQueryListViewController") as! ClientQueryListViewController
            //            clientQueryVCObj.isFromMenu = true
            //            self.navigationController?.pushViewController(clientQueryVCObj, animated: true)
            
            break
        case .Contacts: //CONTACTS
            
            //            let contactVCObj = self.storyboard?.instantiateViewController(withIdentifier: "ContactsListViewController") as! ContactsListViewController
            //            contactVCObj.isFromMenu = true
            //            self.navigationController?.pushViewController(contactVCObj, animated: true)
            
            break
        case .Events: //EVENTS
            
            //            let eventsVCObj = self.storyboard?.instantiateViewController(withIdentifier: "EventsViewController") as! EventsViewController
            //            eventsVCObj.isFromMenu = true
            //            self.navigationController?.pushViewController(eventsVCObj, animated: true)
            
            break
        case .BankDetails: //BANK DETAILS
            
            //            let bankdetailVCObj  = self.storyboard?.instantiateViewController(withIdentifier: "BankDetailsViewController") as! BankDetailsViewController
            //            bankdetailVCObj.isFromMenu = true
            //            self.navigationController?.pushViewController(bankdetailVCObj, animated: true)
            
            break
        case .Request: //REQUEST
            
            //            let requestListVCObj = self.storyboard?.instantiateViewController(withIdentifier: "RequestListViewController") as! RequestListViewController
            //            requestListVCObj.isFromMenu = true
            //            self.navigationController?.pushViewController(requestListVCObj, animated: true)
            
            break
        case .Tasks: //TASKS
            
            //            let taskListVCObj = self.storyboard?.instantiateViewController(withIdentifier: "TaskListViewController") as! TaskListViewController
            //            taskListVCObj.isFromMenu = true
            //            self.navigationController?.pushViewController(taskListVCObj, animated: true)
            
            break
        case .Tips: //TIPS
            //
            //            let tipsListVCObj = self.storyboard?.instantiateViewController(withIdentifier: "TipsListViewController") as! TipsListViewController
            //            tipsListVCObj.isFromMenu = true
            //            self.navigationController?.pushViewController(tipsListVCObj, animated: true)
            
            break
        case .Followup: //FOLLOW UP
            
            //            let followUpListVCObj = self.storyboard?.instantiateViewController(withIdentifier: "FollowUpViewController") as! FollowUpViewController
            //            followUpListVCObj.isFromMenu = true
            //            self.navigationController?.pushViewController(followUpListVCObj, animated: true)
            
            break
        case .Holidays: //HOLIDAYS
            
            //            let holidayVCObj = self.storyboard?.instantiateViewController(withIdentifier: "HolidayViewController") as! HolidayViewController
            //            self.navigationController?.pushViewController(holidayVCObj, animated: true)
            
            break
        case .Share: //SHARE
            //
            //            let shareVCObj = self.storyboard?.instantiateViewController(withIdentifier: "ShareViewController") as! ShareViewController
            //            self.navigationController?.pushViewController(shareVCObj, animated: true)
            
            break
        case .Settings: //SETTINGS
            
            //            let dashboardVCObj = self.storyboard?.instantiateViewController(withIdentifier: "DashBoardViewController") as! DashBoardViewController
            //            dashboardVCObj.isFromSettings = true
            //            self.navigationController?.pushViewController(dashboardVCObj, animated: true)
            
            break
        case.Logout: //LOGOUT
            //self.serviceCallForLogout()
            break
        default: //DEFAULT
            break
        }
    }
}
