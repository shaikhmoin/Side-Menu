//
//  WhistleBlowerViewController.swift
//  mySideMenu
//
//  Created by Akash on 6/20/18.
//  Copyright © 2018 Moin. All rights reserved.
//

import UIKit

class WhistleBlowerViewController: UIViewController {
    
    var isFromMenu : Bool = false
    
    @IBOutlet weak var buttonBack: UIButton!
    @IBOutlet weak var buttonMenu: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if isFromMenu == true {
            buttonBack.isHidden = true
            buttonMenu.isHidden = false
        }
        else {
            buttonBack.isHidden = false
            buttonMenu.isHidden = true
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnBack_Clicked(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
